Prereqs
=======

Install the [stomppy](http://code.google.com/p/stomppy) python client
library.

easy_install users can install it by running:

     easy_install http://stomppy.googlecode.com/files/stomp.py-3.0.2a.tar.gz

